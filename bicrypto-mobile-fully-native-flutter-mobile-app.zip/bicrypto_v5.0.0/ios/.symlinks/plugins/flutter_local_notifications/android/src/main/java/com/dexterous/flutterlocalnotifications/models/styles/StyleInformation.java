package com.dexterous.flutterlocalnotifications.models.styles;

import androidx.annotation.Keep;

import java.io.Serializable;

@Keep
public abstract class StyleInformation implements Serializable {}
