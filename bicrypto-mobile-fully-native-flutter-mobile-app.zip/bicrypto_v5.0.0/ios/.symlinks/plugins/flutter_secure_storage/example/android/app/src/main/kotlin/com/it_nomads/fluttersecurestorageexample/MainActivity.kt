package com.it_nomads.fluttersecurestorageexample;

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
