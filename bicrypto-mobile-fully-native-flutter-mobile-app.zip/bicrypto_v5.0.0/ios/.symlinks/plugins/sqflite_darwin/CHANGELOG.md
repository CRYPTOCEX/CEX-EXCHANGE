## 2.4.2

* Requires dart 3.7

## 2.4.1+1

* Allow creating unprotected folder in iOS (issue #924)
  * Fix delete database to properly delete all related files (`-shm`, `-wal`, `-journal`)

## 2.4.1-1

* Add Swift Package Manager support

## 2.4.0-0

* Initial implementation from sqflite v2.3.3+2
