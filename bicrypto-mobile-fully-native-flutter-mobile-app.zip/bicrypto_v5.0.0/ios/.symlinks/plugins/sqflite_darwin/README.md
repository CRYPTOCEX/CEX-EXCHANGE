# sqflite_darwin

The iOS/MacOS implementation of the [sqflite](https://pub.dev/packages/sqflite) plugin.
